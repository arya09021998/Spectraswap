export { default } from './EasterEgg'
